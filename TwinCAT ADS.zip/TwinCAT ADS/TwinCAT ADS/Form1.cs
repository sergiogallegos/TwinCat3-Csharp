﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TwinCAT.Ads;


namespace TwinCAT_ADS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private TcAdsClient ads = new TcAdsClient();
        private int hvar; //init variable handle

        private void Form1_Load(object sender, EventArgs e)
        {
            ads.Connect(851); //Default Port On TwinCAT 
            if (ads.IsConnected == true)
                MessageBox.Show("Connection Ok");
            else
                MessageBox.Show("Connection Nok");

            //define variable handle
            hvar = ads.CreateVariableHandle("MAIN.Run");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ads.WriteAny(hvar, true);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ads.WriteAny(hvar, false);
        }
    }
}
